import "dotenv/config";
import express from "express";
import path from "path";
import cors from "cors";
import { createServer } from "http";
import { Server as SocketIOServer } from "socket.io";
import { createServer as createViteServer } from "vite";
import fs from "fs-extra";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import { getJWTSecret } from "./src/server/services/security.js";

const app = express();
app.set("trust proxy", true);
const httpServer = createServer(app);
export const io = new SocketIOServer(httpServer, {
  cors: { origin: "*" },
});
app.set("io", io);

// Initialize data folders
const DATA_DIR = path.join(process.cwd(), ".data");
const SERVERS_DIR = path.join(DATA_DIR, "servers");
const BACKUPS_DIR = path.join(process.cwd(), "backups");

fs.ensureDirSync(DATA_DIR);
fs.ensureDirSync(SERVERS_DIR);
fs.ensureDirSync(BACKUPS_DIR);
fs.ensureDirSync(path.join(DATA_DIR, "temp"));

if (!fs.existsSync(path.join(DATA_DIR, "users.json"))) fs.writeFileSync(path.join(DATA_DIR, "users.json"), "[]");
if (!fs.existsSync(path.join(DATA_DIR, "servers.json"))) fs.writeFileSync(path.join(DATA_DIR, "servers.json"), "[]");
if (!fs.existsSync(path.join(DATA_DIR, "settings.json"))) fs.writeFileSync(path.join(DATA_DIR, "settings.json"), "{}");

import { attachServerRuntimeSocket, getServerRuntimeLogs } from "./src/server/services/runtime.js";
import { panelEvents } from "./src/server/events.js";

panelEvents.on("log", (serverId, data) => {
  io.to(`server_${serverId}`).emit("log", data);
});


io.use((socket, next) => {
  const token = socket.handshake.auth.token;
  if (!token) return next(new Error("Authentication error"));
  try {
    const verified = jwt.verify(token, getJWTSecret());
    (socket as any).user = verified;
    next();
  } catch (err) {
    next(new Error("Authentication error"));
  }
});

io.on("connection", (socket) => {
  socket.on("joinServer", async (serverId) => {
    socket.join(`server_${serverId}`);
    
    // Ensure logs are streamed if container is already running
    try {
      const serversJSON = await fs.readFile(path.join(DATA_DIR, "servers.json"), "utf8");
      const servers = JSON.parse(serversJSON);
      const server = Array.isArray(servers) ? servers.find((s: any) => s.id === serverId) : null;
      if (server && server.containerId) {
        const logs = await getServerRuntimeLogs(server);
        if (logs) {
           socket.emit("log", logs.trim() + "\n");
        }
        await attachServerRuntimeSocket(server, serverId);
      }
    } catch (e) {
      console.error(e);
    }
  });
  socket.on("leaveServer", (serverId) => {
    socket.leave(`server_${serverId}`);
  });
});

const PORT = 3000;

app.use(express.json({ limit: "50gb" }));
app.use(express.urlencoded({ extended: true, limit: "50gb" }));
app.use(cors());

import apiRoutes from "./src/server/routes/api.js";
app.use("/api", apiRoutes);

import { initSFTPServer } from "./src/server/services/sftp.js";

async function ensureAdminAccount() {
  const usersFile = path.join(DATA_DIR, "users.json");
  const users = await fs.readJSON(usersFile).catch(() => []);
  const adminPassword = "jihan1122";
  const existing = users.find((u: any) => u.username?.toLowerCase() === "jihan");

  if (existing) {
    existing.username = "jihan";
    const roleChanged = existing.role !== "admin";
    existing.role = "admin";
    if (!existing.password || !(await bcrypt.compare(adminPassword, existing.password))) {
      existing.password = await bcrypt.hash(adminPassword, 12);
      existing.passwordVersion = (existing.passwordVersion || 0) + 1;
    } else if (roleChanged) {
      existing.passwordVersion = (existing.passwordVersion || 0) + 1;
    }
  } else {
    users.push({
      id: "admin-jihan",
      username: "jihan",
      password: await bcrypt.hash(adminPassword, 12),
      role: "admin",
      passwordVersion: 0,
      createdAt: new Date().toISOString()
    });
  }

  // There is exactly one privileged account. All other existing admin/owner
  // accounts are safely downgraded to normal users.
  for (const u of users) {
    if (u.username?.toLowerCase() !== "jihan" && (u.role === "admin" || u.role === "owner")) {
      u.role = "user";
      u.passwordVersion = (u.passwordVersion || 0) + 1;
    }
  }

  await fs.writeJSON(usersFile, users, { spaces: 2 });
}

async function startServer() {
  await ensureAdminAccount();
  await initSFTPServer();

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true, allowedHosts: ["gtk.qzz.io"] },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    const publicPath = path.join(process.cwd(), "public");

    // Public home is the supplied HTML. The panel lives under /panel.
    app.get("/", (_req, res) => {
      res.sendFile(path.join(publicPath, "home.html"));
    });

    app.use(express.static(distPath));
    app.use(express.static(publicPath));

    app.get("/panel", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
    app.get("/panel/*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  httpServer.listen(PORT, "0.0.0.0", () => {
    console.log(`NIGHT CLOUD panel running on port ${PORT}`);
  });
}




// Only start server if not imported as a module in tests
const isMain = 
  (typeof require !== 'undefined' && require.main === module) || 
  (process.argv[1] && process.argv[1].includes('server.ts')) ||
  (process.argv[1] && process.argv[1].includes('server.cjs'));

console.log("IS MAIN:", isMain, "TEST_ENV:", process.env.TEST_ENV);
if (true) {
  startServer();
}


process.on('uncaughtException', (err) => {
  console.error('UNCAUGHT EXCEPTION:', err);
  fs.writeFileSync('crash.log', String(err.stack));
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('UNHANDLED REJECTION:', reason);
  fs.writeFileSync('crash.log', String(reason));
});
