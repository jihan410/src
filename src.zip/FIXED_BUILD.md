NIGHT CLOUD BUILD FIX
=======================
The panel Login.tsx, AccountPage.tsx and AdminSettingsPage.tsx import Firebase.
The previous package.json did not include the `firebase` package, which caused Vite
to fail while building Login.tsx. Firebase 11.10.0 has been added.

Use Node 18.18+ or Node 20/22. Then:
  rm -rf node_modules package-lock.json dist
  npm install
  npm run build
  pm2 start ecosystem.config.cjs

If PM2 is already running:
  pm2 restart all
