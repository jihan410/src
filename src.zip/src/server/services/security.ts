import fs from "fs-extra";
import path from "path";
import crypto from "crypto";

const DATA_DIR = path.join(process.cwd(), ".data");
const SECRET_FILE = path.join(DATA_DIR, "jwt-secret");

export function getJWTSecret(): string {
  if (process.env.JWT_SECRET && process.env.JWT_SECRET.trim()) {
    return process.env.JWT_SECRET.trim();
  }
  fs.ensureDirSync(DATA_DIR);
  if (fs.existsSync(SECRET_FILE)) {
    const secret = fs.readFileSync(SECRET_FILE, "utf8").trim();
    if (secret.length >= 32) return secret;
  }
  const secret = crypto.randomBytes(48).toString("hex");
  fs.writeFileSync(SECRET_FILE, secret, { mode: 0o600 });
  return secret;
}
