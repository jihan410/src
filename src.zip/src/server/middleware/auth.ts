import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";
import crypto from "crypto";
import { readJSON, writeJSON } from "../services/db.js";
import { getJWTSecret } from "../services/security.js";

async function getAuthenticatedUser(token: string, requireAdminRole = false) {
  // API key authentication
  if (token.startsWith("jtg-") || token.startsWith("jtg_")) {
    const apiKeys = await readJSON("api_keys.json") || [];
    const keyHash = crypto.createHash("sha256").update(token).digest("hex");
    const apiKey = apiKeys.find((k: any) => k.key_hash === keyHash);
    if (!apiKey || apiKey.revoked) throw Object.assign(new Error("Invalid or revoked API key"), { status: 401 });
    if (apiKey.expires_at && new Date(apiKey.expires_at) < new Date()) throw Object.assign(new Error("API key expired"), { status: 401 });

    const users = await readJSON("users.json") || [];
    const creator = users.find((u: any) => u.id === apiKey.created_by);
    if (!creator || creator.role !== "admin") throw Object.assign(new Error("API key creator is no longer an admin"), { status: 403 });

    apiKey.last_used_at = new Date().toISOString();
    await writeJSON("api_keys.json", apiKeys);
    const user = { id: creator.id, username: creator.username, role: "admin", isApiKey: true, scopes: apiKey.scopes };
    return requireAdminRole ? user : user;
  }

  const decoded = jwt.verify(token, getJWTSecret()) as any;
  const users = await readJSON("users.json") || [];
  const user = users.find((u: any) => u.id === decoded.id);

  if (!user) throw Object.assign(new Error("User not found"), { status: 401 });
  if ((user.passwordVersion || 0) !== (decoded.passwordVersion || 0)) {
    throw Object.assign(new Error("Session expired"), { status: 401 });
  }

  // Never trust the role claim alone. It must match the persisted database role.
  const role = user.role === "admin" ? "admin" : "user";
  if (decoded.role !== role) {
    throw Object.assign(new Error("Invalid session role"), { status: 401 });
  }
  if (requireAdminRole && role !== "admin") {
    throw Object.assign(new Error("Forbidden: Admin access only"), { status: 403 });
  }

  return { ...decoded, role, id: user.id, username: user.username };
}

export const requireAdmin = async (req: Request, res: Response, next: NextFunction) => {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith("Bearer ")) return res.status(401).json({ error: "Unauthorized" });

  try {
    (req as any).user = await getAuthenticatedUser(authHeader.slice(7), true);
    next();
  } catch (err: any) {
    res.status(err?.status || 401).json({ error: err?.message || "Invalid token" });
  }
};

export const requireAuth = async (req: Request, res: Response, next: NextFunction) => {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith("Bearer ")) return res.status(401).json({ error: "Unauthorized" });

  try {
    (req as any).user = await getAuthenticatedUser(authHeader.slice(7), false);
    next();
  } catch (err: any) {
    res.status(err?.status || 401).json({ error: err?.message || "Invalid token" });
  }
};
