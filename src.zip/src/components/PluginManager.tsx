import React, { useEffect, useState } from "react"; 
import { LoadingOverlay } from "../components/LoadingOverlay";
import axios from "axios";
import { Search, Download, RefreshCw, Puzzle, AlertCircle, Box, Server, Cpu } from "lucide-react";

interface Plugin {
  id: string;
  source: 'modrinth' | 'spigot' | 'hangar';
  name: string;
  tag: string;
  downloads: number;
  rating: number;
  icon: string | null;
}

export default function PluginManager({ serverId }: { serverId: string }) {
  const [plugins, setPlugins] = useState<Plugin[]>([]);
  const [loading, setLoading] = useState(false);
  const [isInstalling, setIsInstalling] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const [activeSource, setActiveSource] = useState<'all' | 'modrinth' | 'spigot' | 'hangar'>('all');
  const [statusMsg, setStatusMsg] = useState<{ text: string; type: "success" | "error" } | null>(null);

  const searchPlugins = async (searchQuery: string = "essentials") => {
    try {
      setLoading(true);
      
      const q = searchQuery.trim() || 'essentials';
      const results: Plugin[] = [];
      
      const promises = [];
      
      // Create a clean axios instance for external requests so we don't send our auth token
      const externalAxios = axios.create();
      delete externalAxios.defaults.headers.common['Authorization'];
      
      if (activeSource === 'all' || activeSource === 'modrinth') {
        promises.push(
          externalAxios.get(`https://api.modrinth.com/v2/search?query=${q}&facets=[["project_type:plugin"]]&limit=15`)
            .then(res => {
              res.data.hits.forEach((hit: any) => {
                results.push({
                  id: hit.project_id,
                  source: 'modrinth',
                  name: hit.title,
                  tag: hit.description,
                  downloads: hit.downloads,
                  rating: 0,
                  icon: hit.icon_url
                });
              });
            }).catch(() => {})
        );
      }
      
      if (activeSource === 'all' || activeSource === 'spigot') {
        promises.push(
          externalAxios.get(`https://api.spiget.org/v2/search/resources/${q}?field=name&size=15&page=1`)
            .then(res => {
              if(Array.isArray(res.data)) {
                res.data.forEach((hit: any) => {
                  results.push({
                    id: hit.id.toString(),
                    source: 'spigot',
                    name: hit.name,
                    tag: hit.tag,
                    downloads: hit.downloads,
                    rating: hit.rating ? hit.rating.average : 0,
                    icon: hit.icon?.url ? `https://spigotmc.org/${hit.icon.url}` : null
                  });
                });
              }
            }).catch(() => {})
        );
      }

      if (activeSource === 'all' || activeSource === 'hangar') {
        promises.push(
          externalAxios.get(`https://hangar.papermc.io/api/v1/projects?q=${q}&limit=15`)
            .then(res => {
              if (res.data && res.data.result) {
                res.data.result.forEach((hit: any) => {
                  results.push({
                    id: `${hit.namespace.owner}/${hit.namespace.slug}`,
                    source: 'hangar',
                    name: hit.name,
                    tag: hit.description,
                    downloads: hit.stats?.downloads || 0,
                    rating: 0,
                    icon: null
                  });
                });
              }
            }).catch(() => {})
        );
      }

      await Promise.all(promises);
      
      results.sort((a, b) => b.downloads - a.downloads);
      setPlugins(results);
    } catch (e) {
      console.error(e);
      setPlugins([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    searchPlugins();
  }, [activeSource]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    searchPlugins(query);
  };

  const handleInstall = async (plugin: Plugin) => {
    setStatusMsg(null);
    try {
      setIsInstalling(plugin.id);
      
      const res = await axios.post(`/api/servers/${serverId}/plugins/install`, {
        source: plugin.source,
        pluginId: plugin.id,
        pluginName: plugin.name
      });
      
      setStatusMsg({
        text: res.data.message || `${plugin.name} installed successfully! Restart the server to apply changes.`,
        type: "success"
      });
    } catch (e: any) {
      setStatusMsg({
        text: e.response?.data?.error || "Failed to install plugin.",
        type: "error"
      });
    } finally {
      setIsInstalling(null);
    }
  };

  const getSourceIcon = (source: string) => {
    switch (source) {
      case 'modrinth': return <Box className="w-3 h-3 text-green-400" />;
      case 'spigot': return <Server className="w-3 h-3 text-orange-400" />;
      case 'hangar': return <Cpu className="w-3 h-3 text-zinc-400" />;
      default: return <Puzzle className="w-3 h-3 text-theme-500" />;
    }
  };

  const getSourceName = (source: string) => {
    switch (source) {
      case 'modrinth': return 'Modrinth';
      case 'spigot': return 'SpigotMC';
      case 'hangar': return 'Paper Hangar';
      default: return source;
    }
  };

  return (
    <div className="flex-1 overflow-y-auto custom-scrollbar p-4 md:p-8 text-foreground bg-transparent">
      <div className="max-w-4xl mx-auto space-y-6 md:space-y-8">
        
        <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
          <div>
            <h2 className="text-2xl md:text-3xl font-black text-foreground tracking-tight drop-shadow-md mb-1">Plugin Manager</h2>
            <p className="text-[11px] font-bold text-theme-500/80 uppercase tracking-widest mt-1">Search and install plugins from Modrinth, Spigot, and Paper Hangar.</p>
          </div>
        </div>

        {statusMsg && (
          <div className={`p-3.5 rounded-xl border text-sm flex items-center justify-between ${
            statusMsg.type === "success" 
              ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-400" 
              : "bg-rose-500/10 border-rose-500/30 text-rose-400"
          }`}>
            <span>{statusMsg.text}</span>
            <button onClick={() => setStatusMsg(null)} className="text-xs opacity-70 hover:opacity-100 ml-3">Dismiss</button>
          </div>
        )}

        <div className="bg-black/40 dark:bg-black/40 backdrop-blur-xl border border-border rounded-3xl overflow-hidden shadow-[0_0_40px_-15px_rgba(0,0,0,0.5)] ring-1 ring-border-subtle">
          <div className="p-4 border-b border-border-subtle space-y-4">
            <form onSubmit={handleSearch} className="flex flex-col sm:flex-row gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Search for plugins..."
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  className="w-full bg-muted-subtle border border-border rounded-lg py-2 pl-9 pr-4 text-sm text-foreground placeholder-zinc-500 focus:outline-none focus:border-theme-600 transition-colors"
                />
              </div>
              <button 
                type="submit"
                className="px-4 py-2 bg-theme-600 hover:bg-theme-700 text-foreground rounded-lg text-sm font-medium transition-colors whitespace-nowrap shrink-0"
              >
                Search
              </button>
            </form>
            
            <div className="flex gap-2 overflow-x-auto custom-scrollbar pb-1">
              {['all', 'modrinth', 'spigot', 'hangar'].map(src => (
                <button
                  key={src}
                  type="button"
                  onClick={() => setActiveSource(src as any)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap flex items-center gap-1.5 ${activeSource === src ? 'bg-theme-600 text-foreground' : 'bg-muted text-muted-foreground hover:bg-muted-hover hover:text-foreground'}`}
                >
                  {src === 'all' ? <Puzzle className="w-3.5 h-3.5" /> : getSourceIcon(src)}
                  {src === 'all' ? 'All Sources' : getSourceName(src)}
                </button>
              ))}
            </div>
          </div>
          
          <div className="divide-y divide-border-subtle">
            {loading ? (
              <div className="p-8 text-center text-muted-foreground flex flex-col items-center">
                <RefreshCw className="w-6 h-6 animate-spin mb-3 text-theme-600/50" />
                Searching repositories...
              </div>
            ) : plugins.length === 0 ? (
              <div className="p-8 text-center text-muted-foreground flex flex-col items-center">
                <AlertCircle className="w-8 h-8 mb-3 text-muted-foreground" />
                No plugins found.
              </div>
            ) : (
              plugins.map((plugin) => (
                <div key={`${plugin.source}-${plugin.id}`} className="p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 hover:bg-muted-subtle transition-colors">
                  <div className="flex items-start gap-4 flex-1 min-w-0">
                    <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center shrink-0 overflow-hidden border border-border-subtle">
                      {plugin.icon ? (
                         <img src={plugin.icon} alt={plugin.name} className="w-full h-full object-cover" />
                      ) : (
                         <Puzzle className="w-5 h-5 text-muted-foreground" />
                      )}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                         <h4 className="font-medium text-foreground-muted truncate">{plugin.name}</h4>
                         <span className="px-1.5 py-0.5 rounded text-[10px] uppercase font-bold tracking-wider bg-muted text-muted-foreground flex items-center gap-1">
                            {getSourceIcon(plugin.source)} {plugin.source}
                         </span>
                      </div>
                      <p className="text-xs text-muted-foreground line-clamp-2 mt-1">{plugin.tag}</p>
                      <div className="flex items-center gap-4 mt-2 text-[11px] text-muted-foreground">
                        {plugin.downloads > 0 && (
                          <span className="flex items-center gap-1" title="Downloads">
                            <Download className="w-3.5 h-3.5 text-muted-foreground" />
                            {plugin.downloads.toLocaleString()}
                          </span>
                        )}
                        {plugin.rating > 0 && (
                          <span title="Rating">⭐ {plugin.rating.toFixed(1)}/5</span>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <button
                    onClick={() => handleInstall(plugin)}
                    disabled={isInstalling !== null}
                    className="w-full md:w-auto px-4 py-2 bg-muted hover:bg-theme-600/10 border border-border hover:border-theme-600/30 text-foreground-muted hover:text-theme-500 rounded-lg text-sm font-medium transition-all flex items-center justify-center shrink-0 disabled:opacity-50"
                  >
                    {isInstalling === plugin.id ? (
                      <><RefreshCw className="w-4 h-4 mr-2 animate-spin" /> Installing...</>
                    ) : (
                      <><Download className="w-4 h-4 mr-2" /> Install</>
                    )}
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
      
      {isInstalling !== null && <LoadingOverlay message="Installing plugin..." />}
    </div>
  );
}
