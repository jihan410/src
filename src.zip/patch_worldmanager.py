import re

with open("src/components/WorldManager.tsx", "r") as f:
    content = f.read()

# I will replace the component logic with a completely new one using standard React state

