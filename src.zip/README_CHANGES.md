# Local Process Runtime Changes
All code created for the Local Java process and Runtime abstraction has been bundled into `data_logs.txt`.
You can download or view `data_logs.txt` from the file explorer in the editor to easily copy the implementation.
