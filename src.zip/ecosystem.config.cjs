module.exports = {
  apps: [{
    name: 'night-cloud',
    script: './dist/server.cjs',
    cwd: __dirname,
    env: {
      NODE_ENV: 'production',
      PORT: 3000
    },
    autorestart: true,
    watch: false,
    max_memory_restart: '512M'
  }]
};
