import "dotenv/config";
import bcrypt from "bcryptjs";
import readline from "readline";
import path from "path";
import fs from "fs-extra";

const DATA_DIR = path.join(process.cwd(), ".data");
const USERS_FILE = path.join(DATA_DIR, "users.json");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

fs.ensureDirSync(DATA_DIR);
if (!fs.existsSync(USERS_FILE)) fs.writeFileSync(USERS_FILE, "[]");

console.log("=== NIGHT CLOUD User Creation ===");

rl.question("Username: ", async (username) => {
  rl.question("Password: ", async (password) => {
    if (!username || !password) {
      console.error("Username and password are required.");
      process.exit(1);
    }
    const users = await fs.readJson(USERS_FILE);
    const existingIndex = users.findIndex((u: any) => u.username === username);
    
    const hashedPassword = await bcrypt.hash(password, 10);
    
    if (existingIndex !== -1) {
      // update password but keep the existing role
      users[existingIndex].password = hashedPassword;
      users[existingIndex].passwordVersion = (users[existingIndex].passwordVersion || 0) + 1;
      await fs.writeJson(USERS_FILE, users, { spaces: 2 });
      console.log("User updated successfully.");
      process.exit(0);
    } else {
      users.push({
        id: Date.now().toString(),
        username,
        password: hashedPassword,
        role: "user",
        passwordVersion: 0,
        createdAt: new Date().toISOString()
      });

      await fs.writeJson(USERS_FILE, users, { spaces: 2 });
      console.log("User created successfully.");
      process.exit(0);
    }
  });
});
