# NIGHT CLOUD setup

This build keeps the supplied `public/home.html` as the public home page at `/`.
The existing React panel is available under `/panel`.

## Install

Use Node.js 20 LTS (Node 18.18+ minimum), then:

```bash
sudo npm install -g pm2
npm i
npm run createuser
npm run build
pm2 start ecosystem.config.cjs
```

## Restart

```bash
pm2 restart all
```

## URLs

- `/` = supplied NIGHT CLOUD home HTML
- `/panel/login` = existing panel login page
- `/panel/register` = existing panel register page
- `/panel/` = existing panel dashboard

The home header has LOGIN and REGISTER buttons beside the existing Discord button.
Panel branding is fixed to NIGHT CLOUD with the blue theme.
